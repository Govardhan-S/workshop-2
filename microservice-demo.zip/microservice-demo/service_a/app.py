import logging
from fastapi import FastAPI, HTTPException
from opentelemetry import trace
from opentelemetry.exporter.jaeger.thrift import JaegerExporter
from opentelemetry.sdk.trace import TracerProvider
from opentelemetry.sdk.trace.export import BatchSpanProcessor
from opentelemetry.instrumentation.fastapi import FastAPIInstrumentor
import random

# Setup logging
logging.basicConfig(level=logging.INFO, format="%(asctime)s [%(levelname)s] %(message)s")
logger = logging.getLogger(__name__)

# Setup OpenTelemetry
trace.set_tracer_provider(TracerProvider())
jaeger_exporter = JaegerExporter(agent_host_name="jaeger", agent_port=6831)
trace.get_tracer_provider().add_span_processor(BatchSpanProcessor(jaeger_exporter))
tracer = trace.get_tracer(__name__)

app = FastAPI()
FastAPIInstrumentor.instrument_app(app)

@app.get("/start")
async def start():
    with tracer.start_as_current_span("start_endpoint"):
        trace_id = trace.get_current_span().get_span_context().trace_id
        logger.info(f"Service A: Processing request, trace_id={trace_id:032x}")
        if random.random() < 0.5:
            logger.error(f"Service A: Simulated NullPointerException, trace_id={trace_id:032x}")
            raise HTTPException(status_code=500, detail="NullPointerException in Service A")
        logger.info(f"Service A: Request successful, trace_id={trace_id:032x}")
        return {"status": "success"}