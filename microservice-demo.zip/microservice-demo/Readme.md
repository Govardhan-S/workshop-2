Microservice Demo with Log Analysis
Overview
This project sets up three microservices (A, B, C) with logging, tracing, and ML-based log analysis to identify root cause errors.
Prerequisites

Docker and Docker Compose
Python 3.10
Git

Setup

Clone the repository:git clone <repo-url>
cd microservice-demo


Build and start services:docker-compose up --build



Usage

Trigger Requests:
Access Service C: curl http://localhost:8002/finalize
Service C calls Service B, which calls Service A. Service A may fail randomly (50% chance).


View Traces:
Open Jaeger: http://localhost:16686
Search for traces by trace ID.


Analyze Logs:
Open Streamlit: http://localhost:8501
Click "Analyze Logs" to see root cause errors.


View Logs:
Query Loki via Grafana (optional) or Streamlit UI.



Services

Service A: http://localhost:8000/start
Service B: http://localhost:8001/process
Service C: http://localhost:8002/finalize
Loki: http://localhost:3100
Jaeger: http://localhost:16686
Streamlit: http://localhost:8501

Notes

Logs are stored in SQLite (logs.db) and Loki.
Random Forest model identifies root causes based on log embeddings.
Trace IDs correlate logs across services.

