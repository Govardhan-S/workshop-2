import requests
import pandas as pd
import numpy as np
from sentence_transformers import SentenceTransformer
from sklearn.ensemble import RandomForestClassifier
import sqlite3
import streamlit as st
from opentelemetry import trace
import logging

# Setup logging
logging.basicConfig(level=logging.INFO)
logger = logging.getLogger(__name__)

# Fetch logs from Loki
def fetch_logs(loki_url, query, start_time, end_time):
    params = {"query": query, "start": start_time, "end": end_time}
    response = requests.get(f"{loki_url}/loki/api/v1/query_range", params=params)
    logs = response.json()["data"]["result"]
    return pd.DataFrame([
        {
            "timestamp": entry[0],
            "service": stream["stream"]["service"],
            "message": entry[1],
            "trace_id": stream["stream"].get("trace_id", "")
        }
        for stream in logs for entry in stream["values"]
    ])

# Preprocess logs
def preprocess_logs(logs_df):
    model = SentenceTransformer("all-MiniLM-L6-v2")
    logs_df["embeddings"] = logs_df["message"].apply(lambda x: model.encode(x))
    logs_df["timestamp"] = pd.to_datetime(logs_df["timestamp"], unit="ns")
    return logs_df

# Train ML model (simulated with sample data)
def train_model(logs_df):
    X = np.array([emb for emb in logs_df["embeddings"]])
    # Simulated labels: 1 for Service A errors, 0 otherwise
    y = np.array([1 if "NullPointerException" in row["message"] else 0 for _, row in logs_df.iterrows()])
    clf = RandomForestClassifier(n_estimators=100)
    clf.fit(X, y)
    return clf

# Predict root cause
def predict_root_cause(logs_df, clf):
    X = np.array([emb for emb in logs_df["embeddings"]])
    scores = clf.predict_proba(X)[:, 1]
    logs_df["root_cause_score"] = scores
    return logs_df.sort_values("root_cause_score", ascending=False).iloc[0]

# Correlate logs by trace ID
def correlate_logs(logs_df):
    return {trace_id: group for trace_id, group in logs_df.groupby("trace_id") if trace_id}

# Main analysis
def analyze_logs():
    loki_url = "http://localhost:3100"
    query = '{log_level="ERROR"}'
    logs_df = fetch_logs(loki_url, query, "2025-06-19T00:00:00Z", "2025-06-19T23:59:59Z")
    if logs_df.empty:
        return None
    logs_df = preprocess_logs(logs_df)
    
    # Store in SQLite
    conn = sqlite3.connect("logs.db")
    logs_df.to_sql("logs", conn, if_exists="replace", index=False)
    
    # Train and predict
    clf = train_model(logs_df)
    trace_groups = correlate_logs(logs_df)
    root_causes = []
    for trace_id, group in trace_groups.items():
        root_cause = predict_root_cause(group, clf)
        root_causes.append(root_cause)
    
    return pd.DataFrame(root_causes)

# Streamlit UI
def main():
    st.title("Root Cause Analysis")
    if st.button("Analyze Logs"):
        root_causes = analyze_logs()
        if root_causes is not None and not root_causes.empty:
            for _, row in root_causes.iterrows():
                st.write(f"**Service**: {row['service']}, **Message**: {row['message']}, **Score**: {row['root_cause_score']:.2f}, **Trace ID**: {row['trace_id']}")
        else:
            st.write("No error logs found.")

if __name__ == "__main__":
    main()