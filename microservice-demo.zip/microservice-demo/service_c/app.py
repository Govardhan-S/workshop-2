import logging
import requests
from fastapi import FastAPI, HTTPException
from opentelemetry import trace
from opentelemetry.exporter.jaeger.thrift import JaegerExporter
from opentelemetry.sdk.trace import TracerProvider
from opentelemetry.sdk.trace.export import BatchSpanProcessor
from opentelemetry.instrumentation.fastapi import FastAPIInstrumentor
from opentelemetry.instrumentation.requests import RequestsInstrumentor

# Setup logging
logging.basicConfig(level=logging.INFO, format="%(asctime)s [%(levelname)s] %(message)s")
logger = logging.getLogger(__name__)

# Setup OpenTelemetry
trace.set_tracer_provider(TracerProvider())
jaeger_exporter = JaegerExporter(agent_host_name="jaeger", agent_port=6831)
trace.get_tracer_provider().add_span_processor(BatchSpanProcessor(jaeger_exporter))
tracer = trace.get_tracer(__name__)
RequestsInstrumentor().instrument()

app = FastAPI()
FastAPIInstrumentor.instrument_app(app)

@app.get("/finalize")
async def finalize():
    with tracer.start_as_current_span("finalize_endpoint"):
        trace_id = trace.get_current_span().get_span_context().trace_id
        logger.info(f"Service C: Calling Service B, trace_id={trace_id:032x}")
        try:
            response = requests.get("http://service-b:8000/process")
            response.raise_for_status()
            logger.info(f"Service C: Success, trace_id={trace_id:032x}")
            return {"status": "success"}
        except requests.RequestException as e:
            logger.error(f"Service C: Failed to call Service B, error={str(e)}, trace_id={trace_id:032x}")
            raise HTTPException(status_code=500, detail="Service B failed")