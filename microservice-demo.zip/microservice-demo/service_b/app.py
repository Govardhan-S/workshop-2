import logging
import requests
from fastapi import FastAPI, HTTPException
from opentelemetry import trace
from opentelemetry.exporter.jaeger.thrift import JaegerExporter
from opentelemetry.sdk.trace import TracerProvider
from opentelemetry.sdk.trace.export import BatchSpanProcessor
from opentelemetry.instrumentation.fastapi import FastAPIInstrumentor
from opentelemetry.instrumentation.requests import RequestsInstrumentor

# Setup logging
logging.basicConfig(level=logging.INFO, format="%(asctime)s [%(levelname)s] %(message)s")
logger = logging.getLogger(__name__)

# Setup OpenTelemetry
trace.set_tracer_provider(TracerProvider())
jaeger_exporter = JaegerExporter(agent_host_name="jaeger", agent_port=6831)
trace.get_tracer_provider().add_span_processor(BatchSpanProcessor(jaeger_exporter))
tracer = trace.get_tracer(__name__)
RequestsInstrumentor().instrument()

app = FastAPI()
FastAPIInstrumentor.instrument_app(app)

@app.get("/process")
async def process():
    with tracer.start_as_current_span("process_endpoint"):
        trace_id = trace.get_current_span().get_span_context().trace_id
        logger.info(f"Service B: Calling Service A, trace_id={trace_id:032x}")
        try:
            response = requests.get("http://service-a:8000/start")
            response.raise_for_status()
            logger.info(f"Service B: Success, trace_id={trace_id:032x}")
            return {"status": "success"}
        except requests.RequestException as e:
            logger.error(f"Service B: Failed to call Service A, error={str(e)}, trace_id={trace_id:032x}")
            raise HTTPException(status_code=500, detail="Service A failed")